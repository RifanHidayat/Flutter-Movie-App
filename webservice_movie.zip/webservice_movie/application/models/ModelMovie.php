<?php
class ModelMovie extends CI_Model{


public function kategori($table,$where){

return $this->db->get_where($table,$where);
}

public function cek($table,$where){
	return $this->db->get_where($table,$where);
}

public function tampilAll($table){

return $this->db->get_where($table);
}
public function update($where,$data,$table){
	$this->db->where($where);
	$this->db->update($table,$data);
}

}