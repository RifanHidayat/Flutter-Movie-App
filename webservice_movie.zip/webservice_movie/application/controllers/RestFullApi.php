<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class RestFullAPi extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('ModelMovie');
	}

	public function index()
	{
	    // $response = $this->modelnotes->tampilAll('tb_no',['id_user'=>$this->input->post('id')])->result();
		// echo json_encode($response);
		// header('Content-Type: application/json');
	}
	public function all_movies(){
		$response = $this->ModelMovie->tampilAll('tb_moview')->result();
		$result["data"]=$response;
		echo json_encode($result);
		
	}
	public function cek_favorite(){
	$where=[
		'id_movie'=>$this->input->post('id_movie'),
		'username'=>$this->input->post('username')
	];

	$response=$this->ModelMovie->cek("tb_favorite",$where)->row_array();
	
	if ($response){
	$result["favorite"]=$response['favorite'];
	echo json_encode($result);	
	header('Content-Type: application/json');
	}else{
	$result["favorite"]="2";
		echo json_encode($result);	
	header('Content-Type: application/json');

	}
	

	}
	public function kirim_favorite(){
		$id=$this->input->post('id_movie');
		$username=$this->input->post('username');
		$favorite=$this->input->post('favorite');
	

		$sql="SELECT * FROM tb_favorite where id_movie='$id' AND username='$username'";
		$query = $this->db->query($sql);
        if ($query->num_rows()==1){
        	
			$where=array(
				'id_movie'=>$id,
				'username'=>$username
			);
			$data=array(
			'favorite'=>$favorite);

			$ubah=$this->ModelMovie->update($where,$data,'tb_favorite');
			if ($favorite==1){
				$result['favorite']="1";
				$result['message']="Berhasil Menambahkan ke favorite";
			
			}else{
				$result['favorite']="0";
				$result['message']="Data dihilangkan dari daftar favorite";

			}
				
				echo json_encode($result);
			header('Content-Type: application/json');
			
			
        }else{

        $data=[
					"id_movie"=>$this->input->post("id_movie"),
					"username"=>$this->input->post("username"),
					"favorite"=>$this->input->post("favorite")
				];
        	$tambah=$this->db->insert('tb_favorite',$data);
        	if ($tambah){
        		
			$result['value']=1;	
			$result['favorite']="1";
			$result['message']="Berhasil menambahkan ke daftar favorite";
			}
			echo json_encode($result);
			header('Content-Type: application/json');

	}
}

	public function kategori_movie(){
		
		$response = $this->ModelMovie->kategori('tb_moview',['kategori'=>$this->input->post('kategori')])->result();
		$result["data"]=$response;
		echo json_encode($result);
	
	}
	public function kategori_favorites(){
		$username=$this->input->post('kategori');
		$data=[
			
			'favorite'=>"1",
			'tb_favorite.username'=>$username

		];
		
		 $this->db->select('*');
 		$this->db->from('tb_user');
 		$this->db->join('tb_favorite','tb_favorite.username=tb_user.username');
 		$this->db->join('tb_moview','tb_moview.id_movie=tb_favorite.id_movie');
 		$this->db->where($data);
 		$query = $this->db->get()->result();
 		$result["data"]=$query;
 //return $query->result();

 	echo json_encode($result);


	}
	public function tambah_favorite(){

	}
	public function login(){
		$username=$this->input->post('username');
		$password=$this->input->post('password');
		$user=$this->db->get_where('tb_user',['username'=>$username])->row_array();
		// die;
		if ($user){
			if (password_verify($password,$user['password'])){
				$result['value']=1;
				$result['status']="true";
				$result['message']="Berhasil melakukan Login";
				$result['detail']=$user;
				
				header('Content-Type: application/json');
       		
			}else{
				$result['value']=0;
				$result['status']="false";
				$result['message']="Password yang dimasukkan salah";
				header('Content-Type: application/json');
        				
			}

		}else{		
				$result['value']=0;
				$result['statu']="false";
				$result['message']="username yang dimasukan tidak tersedia";
			
				header('Content-Type: application/json');

		}
		 echo json_encode($result);
	} 

	public function register(){
	
		$email=$this->input->post('email');
		$username=$this->input->post('username');
	
		$where_email=array('email'=>$email);
		$where_username=array('username'=>$username);
		$cekemail=$this->ModelMovie->cek('tb_user',$where_email);
		$cekusername=$this->ModelMovie->cek('tb_user',$where_username);
		if ($cekusername->num_rows()>=1){
			$result['value']=2;
			$result['status']="false";
			$result['message']="username Sudah digunakan";


		}else if ($cekemail->num_rows()>=1){
			$result['value']=2;
			$result['status']="false";
			$result['message']="email Sudah digunakan";


		}else{

				$data=[
				'firts_name'=>$this->input->post('firts_name'),
				'last_name'=>$this->input->post('last_name'),
				'username'=>$this->input->post('username'),
				'email'=>$this->input->post('email'),
				'telp'=>$this->input->post('telp'),			
				'password'=> password_hash($this->input->post('password'), PASSWORD_DEFAULT)
			];
			$daftar=$this->db->insert('tb_user',$data);
			if ($daftar){

			$result['value']=1;	
			$result['status']="true";
			$result['message']="Berhasil melakukan register";


			}else{
			$result['value']=0;	
			$result['status']="false";
			$result['message']="Gagal melakukan register";
			}
		}
	
			echo json_encode($result);
			header('Content-Type: application/json');
	
	} 
}

